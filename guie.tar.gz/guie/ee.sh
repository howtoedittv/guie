#!/bin/bash
# Function to handle Enter key assuming "yes" by default
yes_default() {
    read -p "$1 (default: yes): " response
    if [[ -z "$response" ]]; then
        response="y"
    fi
    echo "$response"
}

# Ask for filename and handle extension
while true; do
    read -p "Enter filename: " filename
    extension="${filename##*.}"
    
    # Base directory
    base_dir=~/Documents

    # Determine the target directory and runner
    case "$extension" in
        py)
            dir="$base_dir/python"
            runner="python3"
            break
            ;;
        scala)
            dir="$base_dir/scala"
            runner="scala"
            break
            ;;
        rb)
            dir="$base_dir/ruby"
            runner="ruby"
            break
            ;;
        R)
            dir="$base_dir/R"
            runner="Rscript"
            break
            ;;
        ru)
            dir="$base_dir/rust"
            runner="cargo run"
            break
            ;;
        go)
            dir="$base_dir/go"
            runner="go run"
            break
            ;;
        c)
            dir="$base_dir/c"
            runner="gcc"
            break
            ;;
        html)
            dir="$base_dir/html"
            runner="thorium-browser"
            break
            ;;
        js)
            dir="$base_dir/js"
            runner="node"
            break
            ;;
        java)
            dir="$base_dir/java"
            runner="javac"
            break
            ;;
        gleam)
            dir="$base_dir/gleam"
            runner="gleam run"
            break
            ;;
        zsh)
            dir="$base_dir/zsh"
            runner="zsh"
            break
            ;;
        bash)
            dir="$base_dir/bash"
            runner="bash"
            break
            ;;
        *)
            echo "No matching directory for extension: $extension"
            echo "Please enter a valid filename with a supported extension."
            continue
            ;;
    esac
done

# Ask for optional subdirectory
read -p "Enter subdirectory inside $(basename "$dir") (leave blank for none): " subdir
if [[ -n "$subdir" ]]; then
    dir="$dir/$subdir"
fi

# Ensure directory exists
mkdir -p "$dir"

# Full path to file
file_path="$dir/$filename"

# Check if file exists
if [[ -f "$file_path" ]]; then
    response=$(yes_default "$filename already exists. Do you want to edit it?")
    if [[ ! "$response" =~ ^[Yy]$ ]]; then
        echo "Exiting..."
        exit 0
    fi
else
    touch "$file_path"
fi

# Move into the directory
cd "$dir" || exit 1

# Loop: open file, run it, check errors
while true; do
    TERM=xterm ee "$file_path"  # <--- YOUR preferred editor remains

    response=$(yes_default "Do you want to run $filename?")
    
    if [[ "$response" =~ ^[Yy]$ ]]; then
        echo "Running $filename with $runner..."

        case "$extension" in
            ru)
                cargo run
                exit_code=$?
                ;;
            c)
                output_file="${filename%.c}.out"
                gcc "$filename" -o "$output_file" -lm
                if [[ $? -eq 0 ]]; then
                    ./"$output_file"
                    exit_code=$?
                else
                    exit_code=1
                fi
                ;;
            html)
                $runner "$file_path" &
                exit_code=0
                ;;
            java)
                class_name="${filename%.java}"
                javac "$filename"
                if [[ $? -eq 0 ]]; then
                    java "$class_name"
                    exit_code=$?
                else
                    exit_code=1
                fi
                ;;
            gleam)
                # Gleam requires a project structure
                if [[ -f "gleam.toml" ]]; then
                    $runner
                    exit_code=$?
                else
                    echo "No gleam.toml found. Gleam requires a project structure."
                    echo "Run 'gleam new .' or 'gleam new <project>' to initialize."
                    exit_code=1
                fi
                ;;
            zsh)
                zsh "$filename"
                exit_code=$?
                ;;
            bash)
                bash "$filename"
                exit_code=$?
                ;;
            *)
                $runner "$filename"
                exit_code=$?
                ;;
        esac

        if [[ $exit_code -ne 0 ]]; then
            echo "There was an error (exit code $exit_code). Fix it in ee."
            read -p "Press Enter to continue editing..." dummy
        else
            echo "Program ran successfully!"
            
            
            response=$(yes_default "Do you want to edit a new file? (y/n)")
            
            if [[ ! "$response" =~ ^[Yy]$ ]]; then
                echo "Exiting... "
                sleep 2  # Optional delay before closing
                exit 0  # Now properly exit here
            fi

            # We are using `exec` to exit the current process, and then open the script in a new terminal.
            sleep 3
            clear
            exec bash -c 'source /home/barry/ee.sh; exec bash'  # This is where the new shell takes over.

        fi
    else
        break
    fi
done

